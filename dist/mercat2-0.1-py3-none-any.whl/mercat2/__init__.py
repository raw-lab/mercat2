
#__version__ = "0.1"
#__import__('pkg_resources').declare_namespace("mercat")
#from . import mercat
